<?php
/**
 * The template for displaying the footer-none.
 *
 * Contains the closing of the content div and all content after
 *
 * @author Swlabs
 * @since 1.0
 */
?>
					</div>
					<!-- MAIN CONTENT-->
				</div>
				<!-- PAGE WRAPPER -->
			</div>

		</div>
		<!-- End #page -->
		<?php wp_footer(); ?>
	</body>
</html>