<?php
/**
 * The template for displaying Category pages
 * 
 * @author Swlabs
 * @package Exploore
 * @since 1.0
 */
do_action('slzexploore_show_index');