<?php
/**
 * The template for displaying Tag pages
 *
 * Used to display archive-type pages for posts in a tag.
 * 
 * @author Swlabs
 * @package Exploore
 * @since 1.0
 */
do_action('slzexploore_show_index');