<div class="search-widget widget margin-bottom70">
	<form action="<?php echo esc_url( home_url( '/' ) ) ?>">
		<div class="input-group search-wrapper">
			<input type="text" placeholder="<?php esc_html_e('Search...', 'exploore')?>" class="search-input form-control" name="s">
			<span class="search-result-btn">
			<button type="submit" class="searchbutton fa fa-search btn submit-btn "></button>
			</span>
		</div>
	</form>
</div>