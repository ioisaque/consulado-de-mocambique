<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<input type="text" placeholder ="<?php esc_html_e('Search here...', 'exploore');?>" class="search-field search-input form-control searchbox" name="s"/>
	<button type="submit" class="searchbutton btn-search fa fa-search"></button>
</form>