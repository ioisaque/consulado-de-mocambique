<?php
/**
 * Template Name: Register Template
 * 
 * @author Swlabs
 * @package Exploore
 * @since 1.0
 */
get_template_part( 'inc/template', 'register' );
