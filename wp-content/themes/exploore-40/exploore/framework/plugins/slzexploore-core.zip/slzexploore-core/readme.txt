== Slzexploore_Core ==
Contributors: Rubik Themes
Tags: custom post type, shortcode, metabox.

Slzexploore_Core plugin compatible with Exploore Wordpress template.

Thanks for your support and feel free to contact us any time. 
Our support gateway is here:

http://rubikthemes.com/support/

== Changelog ==
= 4.0 - 06/23/2017 =
